Synthetic CSV recipe, Python 3.11+, standard library only.
python3 file-recipes.py csv-merge input output
Expected: 4 input rows, 3 output rows, 1 duplicate, EUR 37.30.
The record_id is globally unique in this recipe. Map source-specific IDs before using unrelated exports.
Original input files stay unchanged. Use a new output name for each run.
