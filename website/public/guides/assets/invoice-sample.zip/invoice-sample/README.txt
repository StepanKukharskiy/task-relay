Synthetic invoice recipe, Python 3.11+ and pypdf.
Review patterns.json for the exact label format.
python3 file-recipes.py invoice-preview input patterns.json plan.json
Inspect plan.json, then:
python3 file-recipes.py invoice-apply input plan.json output
Original input files stay unchanged. Use a new output name for each run.
