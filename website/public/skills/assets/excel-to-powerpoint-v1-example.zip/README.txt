Excel to PowerPoint Skill — public example v1

Use this folder with an AI agent that can read/write XLSX and PPTX. Give it the Skill, example/january.xlsx, example/february.xlsx, example/report-template.pptx, example/report-mapping.json, example/source-policy.txt and example/request.txt. Compare its new output with the supplied verified example/february-report.pptx. Work on copies and choose a new output filename.

The reference script was actually exercised in Codex, coordinated by Relay. It requires host-provided @oai/artifact-tool, the installed Presentations validation tools, Node.js and Python. It does not bundle those dependencies or install them. Ask your agent to discover their paths through its host dependency loader. If unavailable, use that host's document tools to implement the mapping and independently check the result; that path has not been validated here.

Reference invocation from this bundle, with host paths resolved:
NODE excel-to-powerpoint/scripts/update-report.mjs --template example/report-template.pptx --data example/february.xlsx --mapping example/report-mapping.json --output results/new-february-report.pptx --tools-dir PRESENTATIONS_SKILL_DIR --python BUNDLED_PYTHON
Create results first. Set RUNTIME_NODE_MODULES to the host's bundled modules path and make them resolvable beside the adapter (for example via node_modules). The adapter refuses to overwrite an existing output or an input. It writes a receipt and six previews, with native-package checks kept in build/. Never substitute installation-specific paths copied from someone else's machine.

Included supported template: 6 slides, 1280 x 720, Arial, GBP, one series per chart. The Skill can guide another report, but the reference adapter requires mapping and template adaptation/retesting. January's two observed trend months become three in February. Embedded chart workbooks are editable snapshots, not live links.

The example uses actual historical public transactions aggregated under a declared gross-product-sales policy. Our own template and cell/object mapping were prepared before execution. Source attribution: Chen, D. (2015), Online Retail, UCI Machine Learning Repository, https://doi.org/10.24432/C5BW33. Dataset license CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Original source download: https://archive.ics.uci.edu/static/public/352/online+retail.zip
Changes: selected periods, aggregation into monthly workbooks, our own template and an updated February deck. See example/source-policy.txt, source-provenance.json and verification.json. The full original XLSX and transaction/customer IDs are not bundled.

Verified bounded trial: 31/31 mapped numeric targets, 3/3 complete editable chart datasets, 8/8 period labels; saved slide geometry/style checks pass. One missing causal explanation is explicitly flagged. Keynote opened all 6 slides but reported a font warning and changed chart/border formatting. PowerPoint itself and other agent hosts were not tested. No customer validation or measured time saving is claimed.

Privacy: these instructions and adapter contain no publisher telemetry. Website download counts do not establish Skill execution or installation. Your selected agent/model still processes the inputs under your chosen host/provider settings.

Skill and adapter code: MIT license, see LICENSE.txt. Derived data: CC BY 4.0 with attribution above.
